<script>
function showUser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","getuser.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
<form class="form-horizontal" action="reportroute.php">
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Route ID</label>
        <div class="col-sm-6">
            <select class="form-control" name="route" required>
                <div id="txtHint"></div>
                <?php
                $sql = "SELECT * FROM `work` WHERE `Type` = 'Route'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $count++;
                        echo "<option>".$row["ID"]."</option>";
                    }
                }
                ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Company ID</label>
        <div class="col-sm-6">
            <select class="form-control" name="company" required onchange="showUser(this.value)" required>
                <div id="txtHint"></div>
                <?php
                $sql = "SELECT `ID`, `Name` FROM `company`";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    $count = 0;
                    echo "<option value=''>Select a Company</option>";
                    while($row = $result->fetch_assoc()) {
                        $count++;
                        echo "<option value=".$count.">".$row["ID"]."</option>";
                    }
                }
                ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Distributor ID</label>
        <div class="col-sm-6">
            <select class="form-control" name="id" required id="mySelect">
                <option id="txtHint"></option>
            </select>
        </div>
    </div>     
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Date</label>
        <div class="col-sm-6">
            <input type="date" class="form-control" name="date" placeholder="Enter date" required>
        </div>
    </div>     
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">SIM</label>
        <div class="col-sm-6">
            <input type="number" step="any" class="form-control" name="sim" placeholder="Enter the number of SIM" required>
        </div>
    </div>     
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">RCV</label>
        <div class="col-sm-6">
            <input type="number" step="any" class="form-control" name="rcv" placeholder="Enter the number of RCV" required>
        </div>
    </div>     
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Promo/Other</label>
        <div class="col-sm-6">
            <input type="number" step="any" class="form-control" name="promo" placeholder="Enter the number of Promo/Other" required>
        </div>
    </div>     
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Kilometer Run</label>
        <div class="col-sm-6">
            <input type="number" step="any" class="form-control" name="km" placeholder="Enter the amount of kilometer runned for the distributor" required>
        </div>
    </div>     
    <div class="form-group">
        <label for="inputname" class="col-sm-2 control-label">Time Taken</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="time" placeholder="Enter the amount of time taken for the required task" required>
        </div>
    </div>
     <div class="form-group">
       <div class="col-sm-offset-2 col-sm-10">
         <button type="submit" class="btn btn-primary">Add Report</button>
       </div>
     </div>
</form>