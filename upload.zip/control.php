<?php
	include('lock.php');
	$username = $_GET["username"];;
	echo "welcome $username";
?>