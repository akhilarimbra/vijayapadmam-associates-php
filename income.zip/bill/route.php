<div>
    <img src="logo.jpg" width="35%" align="right">
</div>
<table class="table table-striped table-hover">
<thead>
    <?php
        $id = $_GET['id'];
        $sql = "SELECT * FROM `work` WHERE `ID` = '$id' and type = 'route'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            //output rows
            while($row = $result->fetch_assoc()){
                echo "<tr><th align='center'>".$row['Name']."</tr>";   
            }
        }
    ?>
</thead>
<table class="table table-striped table-hover">
    <thead>
        <tr>   
            <th>Date</th>
            <th>Company</th>
            <th>Distributor</th>            
            <th>Time Taken</th>
            <th>SIM</th>
            <th>RCV</th>
            <th>Promo/Other</th>
            <th>Kilometre</th>
        </tr>
    </thead>
    <tbody>
       <?php
        $id = $_GET['id'];
        $start = $_GET['startdate'];
        $end = $_GET['enddate'];
        $sql = "SELECT * FROM `route` where ID = '$id' and date >= '$start' and date <= '$end'";
        $result = $conn->query($sql);
        $tsim = 0;
        $trcv = 0;
        $tpromo = 0;
        $tkm = 0;
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                //`Distributor`, `SIM`, `RCV`, `Promo/Other`, `Date`, `KM`, `Time`
                echo "<tr>";
                echo "<td>".$row['Date']."</td>";
                echo "<td>".$row['Company']."</td>";
                echo "<td>".$row['Distributor']."</td>";
                echo "<td>".$row['Time']."</td>";
                echo "<td>".$row['SIM']."</td>";
                $tsim += $row['SIM'];
                echo "<td>".$row['RCV']."</td>";
                $trcv += $row['RCV'];
                echo "<td>".$row['Promo/Other'];
                $tpromo += $row['Promo/Other'];
                echo "<td>".$row['KM'];
                $tkm += $row['KM'];
                echo "<tr>";
            }
        }
        $conn->close();
        ?>
        <tr>
            <td><b>Total</b></td>
            <td><b>---</b></td>   
            <td><b>---</b></td>            
            <td><b>---</b></td>
            <td><b><?php echo $tsim;?></b></td>
            <td><b><?php echo $trcv;?></b></td>
            <td><b><?php echo $tpromo;?></b></td>
            <td><b><?php echo $tkm;?></b></td>
        </tr>
    </tbody>
</table>